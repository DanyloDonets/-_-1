﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace Nigga_s_Dorm
{
    public class Room
    {
        public int Id { get; set; }
        public int Number { get; set; }
        public int Value { get; set; }
        public int Amount { get; set; }
        public int Floor { get; set; }
        public List<Student> Students { get; set; }
    }
}
