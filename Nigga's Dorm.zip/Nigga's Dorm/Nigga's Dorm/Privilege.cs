﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace Nigga_s_Dorm
{
    public class Privilege
    {

        [Key]
        public int Id { get; set; }
        public string Type { get; set; }
        public int Discount { get; set; }
        public List<Student> Students { get; set; }

}
}
